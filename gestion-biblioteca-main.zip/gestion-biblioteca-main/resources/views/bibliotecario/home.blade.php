@extends('layouts.app')

@section('content')
    <h1>Estoy dentro de un bibliotecario</h1>
@endsection
@extends('layouts.app')

@section('content')
    <h1>Estoy dentro de un estudiante</h1>
@endsection
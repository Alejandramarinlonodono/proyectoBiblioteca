@extends('layouts.app')

@section('content')
<home-administrador></home-administrador>
@endsection